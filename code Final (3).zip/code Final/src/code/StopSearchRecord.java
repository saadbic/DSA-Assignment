package code;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Objects;

public class StopSearchRecord {

    private String type;
    private String date; // original string
    private LocalDateTime dateTime; // parsed date
    private int year;
    private int month;
    private String policingOperation;
    private boolean partOfOperation;
    private String latitude;
    private String longitude;
    private String gender;
    private String ageRange;
    private String selfDefinedEthnicity;
    private String officerDefinedEthnicity;
    private String legislation;
    private String objectOfSearch;
    private String outcome;
    private boolean outcomeLinkedToObject;
    private boolean removalOfMoreThanOuterClothing;
    private String policeForce; // optional, from filename

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public StopSearchRecord(
            String type,
            String date,
            String policingOperation,
            boolean partOfOperation,
            String latitude,
            String longitude,
            String gender,
            String ageRange,
            String selfDefinedEthnicity,
            String officerDefinedEthnicity,
            String legislation,
            String objectOfSearch,
            String outcome,
            boolean outcomeLinkedToObject,
            boolean removalOfMoreThanOuterClothing,
            String policeForce) {

        this.type = safe(type);
        this.date = safe(date);
        this.dateTime = parseDate(date);
        this.year = (this.dateTime != null) ? this.dateTime.getYear() : -1;
        this.month = (this.dateTime != null) ? this.dateTime.getMonthValue() : -1;
        this.policingOperation = safe(policingOperation);
        this.partOfOperation = partOfOperation;
        this.latitude = safe(latitude);
        this.longitude = safe(longitude);
        this.gender = safe(gender);
        this.ageRange = safe(ageRange);
        this.selfDefinedEthnicity = safe(selfDefinedEthnicity);
        this.officerDefinedEthnicity = safe(officerDefinedEthnicity);
        this.legislation = safe(legislation);
        this.objectOfSearch = safe(objectOfSearch);
        this.outcome = safe(outcome);
        this.outcomeLinkedToObject = outcomeLinkedToObject;
        this.removalOfMoreThanOuterClothing = removalOfMoreThanOuterClothing;
        this.policeForce = safe(policeForce);
    }

    private String safe(String value) {
        if (value == null || value.trim().isEmpty()) return "Unknown";
        return value.trim();
    }

    private LocalDateTime parseDate(String dateStr) {
        try {
            return LocalDateTime.parse(dateStr, FORMATTER);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    // ---------------- Getter Methods ----------------
    public String getType() { return type; }
    public String getDate() { return date; }
    public LocalDateTime getDateTime() { return dateTime; }
    public int getYear() { return year; }
    public int getMonth() { return month; }
    public String getPolicingOperation() { return policingOperation; }
    public boolean isPartOfOperation() { return partOfOperation; }
    public String getLatitude() { return latitude; }
    public String getLongitude() { return longitude; }
    public String getGender() { return gender; }
    public String getAgeRange() { return ageRange; }
    public String getSelfDefinedEthnicity() { return selfDefinedEthnicity; }
    public String getOfficerDefinedEthnicity() { return officerDefinedEthnicity; }
    public String getLegislation() { return legislation; }
    public String getObjectOfSearch() { return objectOfSearch; }
    public String getOutcome() { return outcome; }
    public boolean isOutcomeLinkedToObject() { return outcomeLinkedToObject; }
    public boolean isRemovalOfMoreThanOuterClothing() { return removalOfMoreThanOuterClothing; }
    public String getPoliceForce() { return policeForce; }

    // ---------------- Outcome helpers ----------------
    public boolean isSuccessful() {
        String o = outcome.toLowerCase();
        return (o.contains("arrest") || o.contains("charge") || o.contains("penalty")) && outcomeLinkedToObject;
    }

    public boolean isPartlySuccessful() {
        String o = outcome.toLowerCase();
        return (o.contains("arrest") || o.contains("charge") || o.contains("penalty")) && !outcomeLinkedToObject;
    }

    public boolean isUnsuccessful() {
        String o = outcome.toLowerCase();
        return o.contains("no further action");
    }

    // ---------------- Filtering helpers ----------------
    public boolean matchesMonthYear(int month, int year) {
        return this.month == month && this.year == year;
    }

    public boolean matchesPoliceForce(String force) {
        return this.policeForce.equalsIgnoreCase(force);
    }

    @Override
    public String toString() {
        return "Date: " + date +
                ", Gender: " + gender +
                ", Age: " + ageRange +
                ", Ethnicity: " + selfDefinedEthnicity +
                ", Object: " + objectOfSearch +
                ", Legislation: " + legislation +
                ", Outcome: " + outcome +
                ", Police Force: " + policeForce;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StopSearchRecord)) return false;
        StopSearchRecord that = (StopSearchRecord) o;
        return Objects.equals(type, that.type) &&
                Objects.equals(date, that.date) &&
                Objects.equals(objectOfSearch, that.objectOfSearch) &&
                Objects.equals(legislation, that.legislation) &&
                Objects.equals(policeForce, that.policeForce);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, date, objectOfSearch, legislation, policeForce);
    }
}
