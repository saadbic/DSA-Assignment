package code;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class StopSearchDataset {

    private List<StopSearchRecord> records;

    public StopSearchDataset() {
        this.records = new ArrayList<>();
    }

    public void addRecord(StopSearchRecord record) {
        records.add(record);
    }

    public int size() {
        return records.size();
    }

    // Feature A: list distinct Objects of Search
    public void listDistinctObjects() {
        Set<String> distinctObjects = new TreeSet<>();
        for (StopSearchRecord r : records) {
            distinctObjects.add(r.getObjectOfSearch());
        }
        System.out.println("Distinct Objects of Search:");
        for (String obj : distinctObjects) System.out.println(" - " + obj);
    }

    // Feature B: display all searches for a chosen Object of Search
    public void displaySearchesForObject(Scanner sc) {
        System.out.print("Enter Object of Search: ");
        String userObject = sc.nextLine().trim().toLowerCase();
        boolean found = false;
        for (StopSearchRecord r : records) {
            if (r.getObjectOfSearch().toLowerCase().equals(userObject)) {
                System.out.println(r);
                found = true;
            }
        }
        if (!found) System.out.println("No records found for: " + userObject);
    }

    // Feature C: categorise outcomes
    public void categoriseOutcomes() {
        int successful = 0, partly = 0, unsuccessful = 0;
        for (StopSearchRecord r : records) {
            if (r.isSuccessful()) successful++;
            else if (r.isPartlySuccessful()) partly++;
            else if (r.isUnsuccessful()) unsuccessful++;
        }
        System.out.println("Successful: " + successful);
        System.out.println("Partly successful: " + partly);
        System.out.println("Unsuccessful: " + unsuccessful);
    }

    // Feature D: most frequent legislation for a given month
    public void mostFrequentLegislation(Scanner sc) {
        System.out.print("Enter month (YYYY-MM): ");
        String month = sc.nextLine().trim();
        Map<String, Integer> counts = new HashMap<>();
        for (StopSearchRecord r : records) {
            if (r.getDate() != null && r.getDate().startsWith(month)) {
                counts.put(r.getLegislation(), counts.getOrDefault(r.getLegislation(), 0) + 1);
            }
        }
        if (counts.isEmpty()) {
            System.out.println("No data for that month.");
            return;
        }
        String topLaw = Collections.max(counts.entrySet(), Map.Entry.comparingByValue()).getKey();
        int max = counts.get(topLaw);
        System.out.println("Most frequent legislation in " + month + ": " + topLaw + " (" + max + " times)");
    }

    // Feature E: highest self-defined ethnic group
    public String findHighestEthnicGroup() {
        Map<String, Integer> counts = new HashMap<>();
        for (StopSearchRecord r : records) {
            counts.put(r.getSelfDefinedEthnicity(), counts.getOrDefault(r.getSelfDefinedEthnicity(), 0) + 1);
        }
        if (counts.isEmpty()) {
            System.out.println("No data available.");
            return null;
        }
        String topGroup = Collections.max(counts.entrySet(), Map.Entry.comparingByValue()).getKey();
        int max = counts.get(topGroup);
        System.out.println("Ethnic group with highest number of searches: " + topGroup + " (" + max + ")");
        return topGroup;
    }

    // Feature F: display results for that group in reverse chronological order
    public void displayGroupResultsReverseOrder(String group) {
        if (group == null) { System.out.println("No group provided."); return; }
        List<StopSearchRecord> groupRecords = new ArrayList<>();
        for (StopSearchRecord r : records) {
            if (r.getSelfDefinedEthnicity().equals(group)) groupRecords.add(r);
        }
        if (groupRecords.isEmpty()) { System.out.println("No records for group: " + group); return; }

        // Sort descending by date string
        groupRecords.sort((r1, r2) -> r2.getDate().compareTo(r1.getDate()));
        System.out.println("Records for group " + group + " (newest first):");
        for (StopSearchRecord r : groupRecords) System.out.println(r);
    }

    // Feature G: filter by police force
    public void displayByPoliceForce(Scanner sc) {
        System.out.print("Enter Police Force: ");
        String force = sc.nextLine().trim().toLowerCase();
        boolean found = false;
        for (StopSearchRecord r : records) {
            if (r.getPoliceForce().toLowerCase().equals(force)) {
                System.out.println(r);
                found = true;
            }
        }
        if (!found) System.out.println("No records for police force: " + force);
    }
}
