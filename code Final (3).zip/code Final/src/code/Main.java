package code;

import java.util.Scanner;

public class Main {

    // store last top group between menu calls
    private static String lastTopGroup = null;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Police Stop and Search Data Analysis System");
        System.out.println("------------------------------------------");

        System.out.print("Enter data directory path (for example: data): ");
        String dir = sc.nextLine().trim();
        if (dir.isEmpty()) dir = "data"; // default

        CsvDataLoader loader = new CsvDataLoader();
        StopSearchDataset dataset = loader.loadFromDirectory(dir);

        System.out.println("Loaded records: " + dataset.size());
        if (dataset.size() == 0) {
            System.out.println("No data loaded. Check your directory and CSV files.");
        }

        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("Menu:");
            System.out.println("1. List all distinct Objects of Search");
            System.out.println("2. Display all searches for a chosen Object of Search");
            System.out.println("3. Categorise Stop and Search outcomes");
            System.out.println("4. Find most frequent legislation for a given month");
            System.out.println("5. Find self-defined ethnic group with highest number of stop and searches");
            System.out.println("6. Display records for that ethnic group in reverse chronological order");
            System.out.println("7. Display records for a chosen Police Force");
            System.out.println("8. Exit");
            System.out.print("Enter your choice (1-8): ");

            String choiceStr = sc.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(choiceStr);
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    dataset.listDistinctObjects();
                    break;
                case 2:
                    dataset.displaySearchesForObject(sc);
                    break;
                case 3:
                    dataset.categoriseOutcomes();
                    break;
                case 4:
                    dataset.mostFrequentLegislation(sc);
                    break;
                case 5:
                    lastTopGroup = dataset.findHighestEthnicGroup();
                    break;
                case 6:
                    if (lastTopGroup == null) {
                        System.out.println("Please run option 5 first to determine the top ethnic group.");
                    } else {
                        dataset.displayGroupResultsReverseOrder(lastTopGroup);
                    }
                    break;
                case 7:
                    dataset.displayByPoliceForce(sc);
                    break;
                case 8:
                    running = false;
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        sc.close();
    }
}
