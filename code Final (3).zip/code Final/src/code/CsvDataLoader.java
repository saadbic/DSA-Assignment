package code;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CsvDataLoader {

    public StopSearchDataset loadFromDirectory(String directoryPath) {
        StopSearchDataset dataset = new StopSearchDataset();

        File folder = new File(directoryPath);
        if (!folder.exists() || !folder.isDirectory()) {
            System.out.println("Data directory not found: " + directoryPath);
            return dataset;
        }

        File[] files = folder.listFiles();
        if (files == null) {
            System.out.println("No files found in directory: " + directoryPath);
            return dataset;
        }

        for (File file : files) {
            if (file.isFile() && file.getName().toLowerCase().endsWith(".csv")) {
                loadFromFile(file, dataset);
            }
        }

        return dataset;
    }

    private void loadFromFile(File file, StopSearchDataset dataset) {
        System.out.println("Loading: " + file.getName());
        String policeForce = extractPoliceForce(file.getName());

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (first) { first = false; continue; } // skip header

                StopSearchRecord record = parseLine(line, policeForce);
                if (record != null) {
                    dataset.addRecord(record);
                } else {
                    System.out.println("Skipped line " + lineNumber + " in " + file.getName());
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file " + file.getName() + ": " + e.getMessage());
        }
    }

    private StopSearchRecord parseLine(String line, String policeForce) {
        try {
            String[] parts = line.split(",", -1); // keep empty fields

            String type = getField(parts, 0);
            String date = getField(parts, 1);
            boolean partOfOp = parseBoolean(getField(parts, 2));
            String policingOperation = getField(parts, 3);
            String lat = getField(parts, 4);
            String lon = getField(parts, 5);
            String gender = getField(parts, 6);
            String ageRange = getField(parts, 7);
            String selfEth = getField(parts, 8);
            String officerEth = getField(parts, 9);
            String legislation = getField(parts, 10);
            String objectOfSearch = getField(parts, 11);
            String outcome = getField(parts, 12);
            boolean linked = parseBoolean(getField(parts, 13));
            boolean removal = parseBoolean(getField(parts, 14));

            return new StopSearchRecord(
                    type, date, policingOperation, partOfOp,
                    lat, lon, gender, ageRange, selfEth, officerEth,
                    legislation, objectOfSearch, outcome, linked, removal, policeForce
            );

        } catch (Exception e) {
            return null;
        }
    }

    private String getField(String[] row, int index) {
        if (index >= 0 && index < row.length) {
            String val = row[index].trim();
            return val.isEmpty() ? null : val;
        }
        return null;
    }

    private boolean parseBoolean(String text) {
        if (text == null) return false;
        text = text.trim().toLowerCase();
        return text.equals("true") || text.equals("yes") || text.equals("1");
    }

    private String extractPoliceForce(String filename) {
        // Example filename: 2023-01-cheshire-police-stop-and-search.csv
        filename = filename.toLowerCase();
        String[] parts = filename.split("-");
        if (parts.length >= 3) {
            return parts[2].replace(".csv", "");
        }
        return "Unknown";
    }
}
