# Police Stop and Search Data Analysis System

## 1. Introduction
This project is a Java console application designed to analyze police stop and search data from CSV files. The system allows users to explore and evaluate stop and search records, providing insights based on search purpose, legislation, ethnicity, and other attributes.

## 2. Objectives
The main objectives of the system are:
- To load and process police stop and search data efficiently.
- To allow analysis of search purposes, outcomes, and demographics.
- To provide both summary statistics and detailed records.
- To offer a customizable feature for additional analysis (SHOWCASE feature).

## 3. System Requirements
- Java Development Kit (JDK) version 11 or higher.
- CSV files containing police stop and search data.

## 4. Data Format
CSV files must adhere to the following naming convention:

YYYY-MM-policeforce-stop-and-search.csv

markdown
 

Example: `2025-06-cheshire-stop-and-search.csv`

Files should be placed in the `data/` folder. The program can read multiple files across different months and police forces. Any missing or erroneous data is logged and skipped during processing.

## 5. How to Run
1. Place all CSV files in the `data/` folder.
2. Compile the Java program:
   ```bash
   javac Main.java
Run the program:

bash
 
java Main
Follow the on-screen prompts to select features, filters, or analysis options.

6. Features
The application provides the following functionalities:

List all distinct search purposes ("Object of search").

Output detailed records for a specified search purpose.

Count and categorize searches as:

Successful (arrest, caution, or penalty with relevant outcome)

Partly successful (arrest, caution, or penalty with irrelevant outcome)

Unsuccessful (no further action)

Identify legislation with the highest stop and search frequency per month.

Determine ethnic groups with the highest number of stop and search events.

List search records in reverse chronological order.

Additional SHOWCASE feature: custom analysis using multiple attributes.

7. Notes
The program automatically reads all CSV files in the data/ folder at startup.

Users must select valid filters (e.g., month, police force) from available data.

The system is designed to handle missing or inconsistent data gracefully.

Users can perform multiple analyses in a single program run until choosing to quit.

8. Conclusion
This system provides a structured and efficient approach to analyzing stop and search data. It can be extended to include additional features or integrated with other datasets for deeper insights.





